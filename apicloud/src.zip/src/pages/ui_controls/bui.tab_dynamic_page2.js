﻿loader.define(function(require,exports,module){
    // 模块业务在这里写
    
})