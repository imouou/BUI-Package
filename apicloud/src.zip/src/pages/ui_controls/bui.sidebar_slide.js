﻿loader.define(function(require,exports,module) {

    //示例代码
    var sidebar = bui.sidebar({
        id: "#sidebarSlide" //菜单的ID(必须)
    });

    // 快速初始化
    var uiSlide = bui.slide({
        id:"#slideSide",
        height:200,
        zoom: true,
        autoplay: true
    })
})
