﻿loader.define(function(require,exports,module) {

    router.$('#btnBottom').on("click",function  (argument) {
        bui.alert({"id":"可以显示对象"});
    })
})
