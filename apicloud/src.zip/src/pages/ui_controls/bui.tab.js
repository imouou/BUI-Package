﻿loader.define(function(require,exports,module) {

    var uiTab = bui.tab({
            id:"#uiTab"
        });
    
})
