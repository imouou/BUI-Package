﻿loader.define(function(require,exports,module) {

    //按钮在tab外层,需要传id
    var tab = bui.tab({
        id:"#tabFoot",
        menu:"#tabFootNav"
    })
})
