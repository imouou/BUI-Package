﻿loader.define(function(require,exports,module) {

    // 快速初始化
    var uiSlide = bui.slide({
        id:"#slideScreen",
        fullscreen:true,
        direction:"y"
    })
})
