﻿loader.define(function(require,exports,module) {

    // 通知
    var uiSlide = bui.slide({
        id:"#slideNote",
        height:100,
        autoplay: true,
        loop: true,
        zoom: true,
        direction: "y"
    })
})
