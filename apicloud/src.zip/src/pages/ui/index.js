﻿loader.define(function(require,exports,module) {

    // 初始化折叠菜单
	bui.accordion().showFirst();
})
