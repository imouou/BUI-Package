﻿// 默认已经定义了main模块
loader.define(function(require,exports,module) {

    var uiDropdown = bui.dropdown({
            id: "#uiDropdown",
            relative: false
        });
})
