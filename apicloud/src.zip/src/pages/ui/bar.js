﻿loader.define(function(require,exports,module){

    //下拉菜单 在顶部右边
    var barRight = bui.dropdown({
        id: "#barRight",
        showArrow: true,
        width: 200
    });

    //下拉菜单 在顶部中间
    var barMain = bui.dropdown({
        id: "#barMain",
        showArrow: true,
        relative: false
    })

})