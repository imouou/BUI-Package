loader.define(function(require, exports, module) {
    bui.accordion({
        id: "#method"
    });

})