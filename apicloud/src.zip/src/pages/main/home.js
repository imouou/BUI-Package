// 默认已经定义了main模块
loader.define(function(require, exports, module) {
    // 初始化折叠菜单
    bui.accordion().showAll();

})